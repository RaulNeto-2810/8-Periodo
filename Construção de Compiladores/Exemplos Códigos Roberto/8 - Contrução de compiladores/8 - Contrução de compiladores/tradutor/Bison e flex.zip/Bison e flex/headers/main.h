#ifndef MAIN_H
#define MAIN_H

#include <iostream>
#include <string>
#include <sstream>
#include <unordered_map>
#include <map>
#include <vector>
#include <stack>

#define oi(N) cout << "oi "<< N << endl

using namespace std;

#endif